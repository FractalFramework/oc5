<?php

namespace App\Controllers;
use App\Models\Main;
use App\Models\Db;

class Category extends Main{

    protected static $table='cats';
    public $category='';
    public $id=0;

    public static function all(){
        $sql='select id,category from '.self::$table.'';
        $class='\App\Controllers\Category';
        return Db::getDb()->query($sql,$class);
    }

    public static function find($id){
        $sql='select category from '.self::$table.' where id=?';
        $class='\App\Controllers\Category';
        return Db::getDb()->prepare($sql,[$id],$class,1);
    }

    public function getUrl(){
        return 'cat/'.$this->id;
    }


}