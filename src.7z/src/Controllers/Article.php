<?php

namespace App\Controllers;
use App\Models\Main;
use App\Models\Db;

class Article extends Main{

    public $id='';
    public $title='';
    public $content='';
    public $category='';
    protected static $table='posts';
    
    public static function post(int $id){
        $sql='select id,title,content from '.self::$table.' where id=?';
        $class='\App\Controllers\Article';
        $one_result=1;
        return Db::getDb()->prepare($sql,[$id],$class,$one_result);
    }

    /*public static function all(){
        $sql='select :posts.id,title,content,category
        from :posts
        left join :cats
        on cats.id=catid';
        $blind=['posts'=>self::$table,'cat'=>'cats'];
        $class='\App\Controllers\Article';
        $one_result=0;
        return Db::getDb()->prepare($sql,$blind,$class,$one_result);
    }*/

    public static function all(){
        $sql='select '.self::$table.'.id,title,content,category
        from '.self::$table.'
        left join cats
        on cats.id=catid
        order by '.self::$table.'.up desc';
        return self::query($sql);
    }

    public static function lasts(){
        $sql='select '.self::$table.'.id,title,content,category
        from '.self::$table.'
        left join cats
        on cats.id=catid
        limit 10';
        $class='\App\Controllers\Article';
        $one_result=0;
        return Db::getDb()->prepare($sql,[],$class,$one_result);
    }

    /*public static function artByCat($catid){
        $sql='select '.self::$table.'.id,title,content,category
        from '.self::$table.''
        left join cats
        on cats.id=catid
        where catid=?';
        $blind=[$catid];
        $class='\App\Controllers\Article';
        $one_result=0;
        return Db::getDb()->prepare($sql,$blind,$class,$one_result);
    }*/

    public static function artByCat($catid){
        $sql='select '.self::$table.'.id,title,content,category
        from '.self::$table.'
        left join cats
        on cats.id=catid
        where catid=?
        order by '.self::$table.'.up desc';
        $blind=[$catid];
        return self::query($sql,$blind);
    }
    
    public static function categories(){
        $sql='select id,title,content from '.self::$table.' where id=?';
        $blind=[1];
        $class='\App\Controllers\Article';
        $one_result=0;
        return Db::getDb()->prepare($sql,$blind,$class,$one_result);
    }

    public function getUrl(){
        return '/'.$this->id;
    }
    public function getTitle(){
        return $this->title;
    }
    public function getContent(){
        return $this->content;
    }
    public function getCategory(){
        return $this->category;
    }

}